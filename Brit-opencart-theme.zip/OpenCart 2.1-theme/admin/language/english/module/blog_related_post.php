<?php

// Heading Goes here:
$_['heading_title']    = '<b>Blog Product Related Posts</b>';

// Text
$_['text_success']     = 'Success: You have modified module Blog Related Posts!';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify module Blog Related Posts!';

?>
