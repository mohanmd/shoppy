<?php
class RevSliderParams extends UniteElementsBaseRev{	
	public function updateFieldInDB($name,$value)
	{
			$arr = $this->db->fetch(GlobalsRevSlider::$table_settings);
			if(empty($arr)){
				$arrInsert = array();
				$arrInsert["general"] = "";
				$arrInsert["params"] = "";
				$arrInsert[$name] = $value;
				$this->db->insert(GlobalsRevSlider::$table_settings,$arrInsert);
			}else{
				$arrUpdate = array();
				$arrUpdate[$name] = $value;
				$id = $arr[0]["id"];
				$this->db->update(GlobalsRevSlider::$table_settings,$arrUpdate,array("id"=>$id));
			}
	}
	public function getFieldFromDB($name)
	{
		$value = '';
		$arr = $this->db->fetch(GlobalsRevSlider::$table_settings);
			if(empty($arr))
				return("");
			$arr = $arr;
			if(array_key_exists($name, $arr) == false)
				UniteFunctionsRev::throwError("The settings db should cotnain field: $name");
			if(isset($arr[$name]))
				$value = $arr[$name];
			return($value);
	}
}
?>